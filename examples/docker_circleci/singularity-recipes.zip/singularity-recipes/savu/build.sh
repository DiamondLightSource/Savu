
$PYTHON -m pip install . --no-deps --ignore-installed -vv
