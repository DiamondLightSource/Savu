#!/bin/bash

$PYTHON setup.py install --facility $FACILITY   # Python command to install the script.
