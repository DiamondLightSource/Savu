export PATH=./bin:$PATH
export LD_LIBRARY_PATH=./lib:$LD_LIBRARY_PATH
export PYTHONUSERSITE True
export PATH=/dls_sw/apps/savu/nics_test_install/Savu_1.2//miniconda/bin/bin:$PATH
export LD_LIBRARY_PATH=/dls_sw/apps/savu/nics_test_install/Savu_1.2//miniconda/bin/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/dls_sw/apps/savu/nics_test_install/Savu_1.2//miniconda/lib/python2.7/site-packages/astra/lib:$LD_LIBRARY_PATH
export PATH=/dls_sw/apps/cuda/bin:$PATH
export LD_LIBRARY_PATH=/dls_sw/apps/cuda/lib:$LD_LIBRARY_PATH
export FFTWDIR=/dls_sw/apps/fftw/3.3.3/64/5
export LD_LIBRARY_PATH=/dls_sw/apps/fftw/3.3.3/64/5/lib:$LD_LIBRARY_PATH
