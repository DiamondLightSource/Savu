#!/bin/bash

$PYTHON setup.py install --facility temp   # Python command to install the script.

